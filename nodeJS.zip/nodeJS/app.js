//execute with <node filename.js>
//credentials: root, mysql

const { faker } = require('@faker-js/faker'); // INSERT FAKER
var mysql = require('mysql'); //INSERT NODE 'MYSQL'


//CREATE CONNECTION
var connection = mysql.createConnection({
	host : 'localhost',
	user : 'root',
	database : 'join_us'
});



// MARK: SELECT DATA!

// var queryOne = 'SELECT COUNT(*) AS total FROM users';

// connection.query(queryOne, function (error, results, fields){
// 	if (error) throw error;
// 	console.log(results);
// }); // note: (results[1].email) will return just the email from the chosen array index.

// connection.end();



//MARK: INSERT DATA (dynamically)!

// var user = {email: faker.internet.email(), 
// 			created_at: faker.date.past()
// }; 
// create javascript object with as many properties as needed

// connection.query('INSERT INTO users SET ?', user, function (error, results, fields){
// 	if (error) throw error;
// 	console.log(results);
// });

// connection.end();



//MARK: MASS INSERT DATA!

// var userData = [];

// var query = 'INSERT INTO users (email, created_at) VALUES ?';

// for (var i = 0; i < 500; i++){
// userData.push([
// 	faker.internet.email(), 
// 	faker.date.past()]
// 	);
// }

// connection.query(query, [userData], function (error, results){
// 	if (error) throw error;
// 	console.log(results);
// });

// connection.end();








